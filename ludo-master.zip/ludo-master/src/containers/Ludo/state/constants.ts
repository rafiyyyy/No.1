export const NAME = 'ludo';
