export const NAME = 'contextMenu';
